module.exports = {
    //Response messages
    SOMETHING_WRONG : 'Something went wrong. Please try later.',
    SERVER_ERR : 'Internal server error. Please try later.',
    USER_CREATED_SUCCESS : 'User created successfully',
};
