module.exports = {
    superSecret : 'xyz@123',
    bcryptSalt : 10,
    dbHost : 'localhost',
    dbName : 'node-js-training',
    dbUser : 'root',
    dbPassword : 'root123',
    EMAIL_USERNAME : 'emamul.khan@gmail.com',
    EMAIL_PASSWORD : 'xxxxx',
};
