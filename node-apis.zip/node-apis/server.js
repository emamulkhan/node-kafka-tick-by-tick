//var express = require('express'),
//  app = express(),
//  port = process.env.PORT || 3000;

//app.listen(port);

//console.log('todo list RESTful API server started on: ' + port);


var app = express();
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json());
app.use(expressValidator());

app.use('/v1.0',route); //Set prefix in route v1.0; redirect the routes to the routes.js file;

//create app listner
app.listen(port, console.log('Application is running at ' + port));

//export the instance of express
module.exports = app;
