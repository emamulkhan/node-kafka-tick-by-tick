var routes = require('express').Router(); //create instance of express routes
var userValidator = require('./../validations/user.validation'); //path to the validation/user.validation.js
var userController = require('./../controllers/user.controller'); //path to the controller/user.controller.js

//create the routes
routes.post('/adduser',
    [
	userValidator.validateAddUser, //function that validate request using express-validator
	userValidator.checkValidationResult
    ],
    userController.createUser //controller function that actually perform business logic
);
