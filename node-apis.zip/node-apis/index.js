express         = module.exports = require('express');
bodyParser      = module.exports = require('body-parser');
expressValidator= module.exports = require('express-validator');
//fileUpload      = module.exports = require('express-fileupload');
jwt             = module.exports = require('jsonwebtoken');
fs              = module.exports = require('fs');
//nodemailer      = module.exports = require('nodemailer');
let routes      = require('./routes'); //path to the routes.js
connection      = require('./config/database') //path to the config/database.js
//logger          = require('./logs'); //path to the logs/index.js

var port = process.env.PORT || 3030;
